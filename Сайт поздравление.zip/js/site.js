(async function(){
  const data = await getData();
  document.body.dataset.theme = (data.theme && data.theme.preset) || 'original';
  document.body.dataset.menuStyle = (data.theme && data.theme.menuStyle) || 'cards';

  // Вход по ключу: декоративная защита самого подарка.
  const gate = document.getElementById('accessGate');
  if (data.security && data.security.enabled && data.security.password) {
    gate.classList.remove('hidden');
    document.getElementById('accessQuestion').textContent = data.security.question || 'Введите ключ';
    document.getElementById('accessHint').textContent = data.security.hint || '';
    const unlock = () => {
      if (document.getElementById('accessInput').value === String(data.security.password)) {
        gate.classList.add('hidden'); sessionStorage.setItem('giftUnlocked','1'); startMusic(true);
      } else document.getElementById('accessError').classList.remove('hidden');
    };
    if (sessionStorage.getItem('giftUnlocked') === '1') gate.classList.add('hidden');
    document.getElementById('accessBtn').addEventListener('click', unlock);
    document.getElementById('accessInput').addEventListener('keydown', e => { if(e.key==='Enter') unlock(); });
  }

  // Пользовательская музыка. Браузеры могут запрещать autoplay до первого жеста.
  const audio = document.getElementById('giftAudio');
  const musicToggle = document.getElementById('musicToggle');
  if (data.music && data.music.enabled && data.music.src) {
    audio.src = data.music.src; audio.volume = Math.max(0, Math.min(1, Number(data.music.volume ?? .35)));
    musicToggle.classList.remove('hidden');
    musicToggle.addEventListener('click', e => { e.stopPropagation(); audio.paused ? audio.play().catch(()=>{}) : audio.pause(); updateMusicButton(); });
    audio.addEventListener('play', updateMusicButton); audio.addEventListener('pause', updateMusicButton);
    if (data.music.autoplay) startMusic(false);
    document.addEventListener('pointerdown', () => { if(data.music.autoplay && audio.paused) audio.play().catch(()=>{}); }, {once:true});
  }
  function startMusic(force){ if(!data.music?.enabled || !data.music.src) return; if(force || data.music.autoplay) audio.play().catch(()=>{}); }
  function updateMusicButton(){ musicToggle.textContent = audio.paused ? '♫' : '❚❚'; }

  const screens = {
    intro: document.getElementById('screen-intro'),
    envelope: document.getElementById('screen-envelope'),
    letter: document.getElementById('screen-letter'),
    menu: document.getElementById('screen-menu'),
    movie: document.getElementById('screen-movie'),
  };

  function goTo(name){
    Object.values(screens).forEach(s => s.classList.remove('active'));
    screens[name].classList.add('active');
    window.scrollTo({top:0, behavior:'instant' in window ? 'instant' : 'auto'});
  }

  /* ---------------- render data into DOM ---------------- */
  document.getElementById('introLine1').textContent = data.intro.line1;
  document.getElementById('introLine2').textContent = data.intro.line2;
  document.getElementById('envelopeName').textContent = data.recipient;
  document.getElementById('envelopeHint').textContent = data.envelope.hint;

  document.getElementById('letterKicker').textContent = data.letter.kicker;
  document.getElementById('letterTitle').textContent = data.letter.title;
  const bodyEl = document.getElementById('letterBody');
  bodyEl.textContent = data.letter.body;
  if (data.letter.handwriting === 'serif') bodyEl.classList.add('style-serif');
  else if (data.letter.handwriting === 'simple') bodyEl.classList.add('style-simple');
  document.getElementById('letterFrom').textContent = data.letter.from;
  document.getElementById('thanksBtn').textContent = data.thanksButtonLabel;

  const photosWrap = document.getElementById('letterPhotos');
  (data.photos || []).forEach(p => {
    if (!p || !p.src) return;
    const fig = document.createElement('div');
    fig.className = 'letter-photo';
    fig.innerHTML = `<img src="${p.src}" alt="">${p.caption ? `<div class="letter-photo-cap">${escapeHtml(p.caption)}</div>` : ''}`;
    photosWrap.appendChild(fig);
  });

  document.getElementById('menuTitle').textContent = data.menu.title;
  const menuList = document.getElementById('menuList');
  let chosenItem = data.menu.items[0];
  data.menu.items.forEach(item => {
    const btn = document.createElement('button');
    btn.className = 'menu-item';
    btn.innerHTML = `<span class="icon">${item.icon}</span><span>${escapeHtml(item.label)}</span>`;
    btn.addEventListener('click', (e) => {
      chosenItem = item;
      spawnHearts(btn);
      setTimeout(() => onMenuChoice(item), 550);
    });
    menuList.appendChild(btn);
  });

  if (data.settings.showBranding) document.getElementById('brandFooter').classList.remove('hidden');

  /* ---------------- farewell image: fades in on scroll, at the very end ---------------- */
  if (data.farewell && data.farewell.enabled && data.farewell.image) {
    const farewellWrap = document.getElementById('farewellWrap');
    document.getElementById('farewellImg').src = data.farewell.image;
    document.getElementById('farewellCaption').textContent = data.farewell.caption || '';
    farewellWrap.classList.remove('hidden');

    const revealEl = document.getElementById('farewellReveal');
    // Экран #screen-movie сам скроллится (overflow-y:auto), а не вся страница,
    // поэтому наблюдатель следит за прокруткой именно внутри него.
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          revealEl.classList.add('in-view');
          observer.unobserve(entry.target);
        }
      });
    }, { root: screens.movie, threshold: 0.2 });
    observer.observe(revealEl);
  }

  function escapeHtml(str){
    const d = document.createElement('div');
    d.textContent = str;
    return d.innerHTML;
  }

  /* ---------------- screen 1 -> 2 ---------------- */
  screens.intro.addEventListener('click', () => goTo('envelope'));

  /* ---------------- screen 2: envelope ---------------- */
  const envelope = document.getElementById('envelope');
  envelope.addEventListener('click', () => {
    if (envelope.classList.contains('open')) return;
    envelope.classList.add('open');
    setTimeout(() => goTo('letter'), 900);
  });

  /* ---------------- screen 3 -> 4 ---------------- */
  document.getElementById('thanksBtn').addEventListener('click', () => goTo('menu'));

  /* floating hearts on menu hover/click */
  function spawnHearts(target){
    const rect = target.getBoundingClientRect();
    const stageRect = document.getElementById('stage').getBoundingClientRect();
    for (let i=0;i<5;i++){
      const h = document.createElement('span');
      h.className = 'floating-heart';
      h.textContent = ['💗','💕','💖','♡'][Math.floor(Math.random()*4)];
      h.style.left = (rect.left - stageRect.left + Math.random()*rect.width) + 'px';
      h.style.top = (rect.top - stageRect.top + Math.random()*rect.height*0.4) + 'px';
      h.style.animationDelay = (Math.random()*0.2)+'s';
      document.getElementById('screen-menu').appendChild(h);
      setTimeout(() => h.remove(), 1600);
    }
  }

  /* ---------------- screen 4 -> 5 ---------------- */
  function onMenuChoice(item){
    if (item.mode === 'movie'){
      goTo('movie');
      initMovieGame(item);
    } else {
      // simple items: just show their final phrase in place of the movie card, no hearts game
      goTo('movie');
      document.getElementById('movieGame').classList.add('hidden');
      showMovieResult(item, 0, true);
    }
  }

  /* ---------------- screen 5: hearts click game ---------------- */
  let heartsCount = 0;
  let target = Math.max(20, Math.min(60, Math.round((data.movie.heartsTarget||9494)/160))); // scaled for a pleasant click count
  let gameDone = false;

  function initMovieGame(item){
    heartsCount = 0;
    gameDone = false;
    document.getElementById('movieGame').classList.remove('hidden');
    document.getElementById('movieResult').classList.add('hidden');
    document.getElementById('movieCounter').textContent = '0';
    const img = document.getElementById('movieFinalPhotoImg');
    img.src = data.movie.photo || '';
    document.getElementById('movieOrb').classList.remove('done');
    document.getElementById('movieTapHint').textContent = data.movie.subtitle || 'нажимай на фото';

    const orb = document.getElementById('movieOrb');
    const newOrb = orb.cloneNode(true);
    orb.parentNode.replaceChild(newOrb, orb);
    newOrb.addEventListener('click', () => onHeartTap(item));
  }

  function onHeartTap(item){
    if (gameDone) return;
    heartsCount++;
    document.getElementById('movieCounter').textContent = heartsCount;
    const pct = Math.min(100, Math.round((heartsCount/target)*100));
    document.getElementById('movieOrb').style.setProperty('--tap-progress', pct + '%');
    burstHeart();
    if (heartsCount >= target){
      gameDone = true;
      document.getElementById('movieOrb').classList.add('done');
      setTimeout(() => showMovieResult(item, data.movie.heartsTarget||9494, false), 500);
    }
  }

  function burstHeart(){
    const wrap = document.getElementById('movieOrb');
    const s = document.createElement('span');
    s.textContent = '♡';
    s.style.position = 'absolute';
    s.style.left = (40 + Math.random()*140) + 'px';
    s.style.top = (40 + Math.random()*140) + 'px';
    s.style.color = 'var(--pink-soft)';
    s.style.fontSize = '1.1rem';
    s.style.pointerEvents = 'none';
    s.style.animation = 'floatUp 1s ease forwards';
    wrap.appendChild(s);
    setTimeout(() => s.remove(), 1000);
  }

  function showMovieResult(item, heartsShown, skipReveal){
    document.getElementById('movieGame').classList.add('hidden');
    const resultEl = document.getElementById('movieResult');
    resultEl.classList.remove('hidden');

    const finalPhotoWrap = document.getElementById('movieFinalPhoto');
    const finalPhotoImg = document.getElementById('movieFinalPhotoImg');
    if (skipReveal){
      finalPhotoWrap.classList.add('hidden');
    } else {
      finalPhotoWrap.classList.remove('hidden');
      if (data.movie.photo){
        finalPhotoImg.src = data.movie.photo;
        finalPhotoWrap.classList.remove('no-photo');
        finalPhotoWrap.textContent = '';
        finalPhotoWrap.appendChild(finalPhotoImg);
      } else {
        finalPhotoImg.src = '';
        finalPhotoWrap.classList.add('no-photo');
        finalPhotoWrap.textContent = '♡';
      }
    }

    const revealText = document.getElementById('movieRevealText');
    if (skipReveal){
      revealText.textContent = '';
      revealText.classList.add('hidden');
    } else {
      revealText.classList.remove('hidden');
      revealText.textContent = `Мне понадобилось ${heartsShown} сердца, чтобы показать одно своё, ${data.recipient}.`;
    }

    document.getElementById('movieFinalTitle').textContent = item.finalPhrase;
    document.getElementById('movieFinalIcon').textContent = item.icon;
    document.getElementById('movieFinalSub').textContent = item.label;

    const shareBtn = document.getElementById('shareBtn');
    shareBtn.style.display = data.settings.allowShare ? '' : 'none';
    const replyBtn = document.getElementById('replyBtn');
    replyBtn.style.display = data.settings.allowReply ? '' : 'none';

    // reset action states
    document.getElementById('savedNote').classList.remove('show');
    document.getElementById('sentNote').classList.remove('show');
    document.getElementById('replyBox').classList.remove('open');
    document.getElementById('replyText').value = '';
    document.getElementById('replyCount').textContent = '0';
    document.getElementById('saveBtn').textContent = 'Сохранить себе';
  }

  /* share */
  document.getElementById('shareBtn').addEventListener('click', async () => {
    const url = data.settings.shareUrl || window.location.href;
    const shareData = { title: 'Это тебе', text: 'Посмотри, что я для тебя сделал ♡', url };
    if (navigator.share){
      try { await navigator.share(shareData); } catch(e){ /* cancelled */ }
    } else {
      try {
        await navigator.clipboard.writeText(url);
        alert('Ссылка скопирована!');
      } catch(e){
        prompt('Скопируй ссылку:', url);
      }
    }
  });

  /* save */
  document.getElementById('saveBtn').addEventListener('click', () => {
    const btn = document.getElementById('saveBtn');
    btn.textContent = 'Сохранено';
    const note = document.getElementById('savedNote');
    note.classList.add('show');
    // try to also save the revealed photo as a file, if present
    const img = document.getElementById('movieFinalPhotoImg');
    if (img.src){
      const a = document.createElement('a');
      a.href = img.src;
      a.download = 'фото.jpg';
      document.body.appendChild(a);
      a.click();
      a.remove();
    }
  });

  /* reply */
  const replyBtn = document.getElementById('replyBtn');
  const replyBox = document.getElementById('replyBox');
  const replyText = document.getElementById('replyText');
  replyBtn.addEventListener('click', () => {
    replyBox.classList.toggle('open');
    if (replyBox.classList.contains('open')) replyText.focus();
  });
  replyText.addEventListener('input', () => {
    document.getElementById('replyCount').textContent = replyText.value.length;
  });
  document.getElementById('replySendBtn').addEventListener('click', async () => {
    const value = replyText.value.trim();
    if (!value) return;
    const sendBtn = document.getElementById('replySendBtn');
    sendBtn.disabled = true;
    const ok = await sendReply(value);
    sendBtn.disabled = false;
    if (ok) {
      replyBox.classList.remove('open');
      document.getElementById('sentNote').classList.add('show');
    } else {
      alert('Не получилось отправить ответ — проверь соединение и попробуй ещё раз.');
    }
  });

})();
