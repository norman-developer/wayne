/* storage.js — shared data layer between index.html (the gift) and admin.html (the editor).

   Данные больше не хранятся в localStorage браузера — они лежат на сервере,
   в файле data/data.json, и читаются/пишутся через простые PHP-скрипты в api/.
   Поэтому изменения, сделанные в редакторе, видят все посетители сайта,
   на любом устройстве и в любом браузере. */

const DATA_URL = 'data/data.json';
const SAVE_URL = 'api/save.php';
const REPLIES_URL = 'api/replies.php';

const DEFAULT_DATA = {
  "recipient": "Именинник",
  "intro": {
    "line1": "Для тебя,",
    "line2": "небольшой подарок"
  },
  "envelope": {
    "hint": "нажми на конверт"
  },
  "letter": {
    "kicker": "несколько слов для тебя.",
    "title": "С днём рождения!",
    "body": "Сегодня особенный день, и этот небольшой сайт создан специально для тебя.\n\nЗдесь можно написать личное поздравление, вспомнить важные моменты и добавить то, что действительно хочется сказать этому человеку.\n\nПусть впереди будет больше хороших событий, приятных встреч и поводов улыбаться!",
    "from": "от близкого человека",
    "handwriting": "handwritten",
    "language": "ru"
  },
  "photos": [
    {
      "src": "",
      "caption": "Наше воспоминание"
    }
  ],
  "thanksButtonLabel": "Спасибо ♡",
  "menu": {
    "title": "Что сделаем дальше?",
    "items": [
      {
        "icon": "🎬",
        "label": "Открыть сюрприз",
        "finalPhrase": "Сюрприз открыт ♡",
        "mode": "movie"
      },
      {
        "icon": "💬",
        "label": "Прочитать ещё пару слов",
        "finalPhrase": "Спасибо, что ты есть)",
        "mode": "simple"
      },
      {
        "icon": "📸",
        "label": "Вспомнить момент",
        "finalPhrase": "Пусть хороших воспоминаний будет больше)",
        "mode": "simple"
      }
    ]
  },
  "movie": {
    "heartsTarget": 20,
    "photo": "",
    "subtitle": "Нажимай на сердечко"
  },
  "farewell": {
    "enabled": true,
    "image": "",
    "caption": "до новых воспоминаний ♡",
    "tapHint": "нажми на фотографию ♡",
    "tapText": "ещё один маленький момент для тебя"
  },
  "settings": {
    "allowShare": true,
    "allowReply": true,
    "showBranding": false,
    "shareUrl": ""
  },
  "meta": {
    "senderName": "",
    "occasion": "День рождения",
    "eventDate": ""
  },
  "security": {
    "enabled": false,
    "question": "Введите ключ, чтобы открыть подарок",
    "hint": "",
    "password": ""
  },
  "music": {
    "enabled": false,
    "src": "",
    "fileName": "",
    "volume": 0.35,
    "autoplay": false
  },
  "theme": {
    "preset": "original",
    "menuStyle": "cards"
  },
  "sections": {
    "intro": true,
    "envelope": true,
    "letter": true,
    "menu": true,
    "interactive": true,
    "farewell": true
  }
};

function deepMerge(base, extra) {
  if (Array.isArray(base)) return extra !== undefined ? extra : base;
  if (typeof base === 'object' && base !== null) {
    const out = { ...base };
    if (extra && typeof extra === 'object') {
      for (const k in base) out[k] = deepMerge(base[k], extra[k]);
    }
    return out;
  }
  return extra !== undefined ? extra : base;
}

function getDefaultData() {
  return JSON.parse(JSON.stringify(DEFAULT_DATA));
}

/* Читает актуальные данные с сервера (data/data.json).
   Если сервер недоступен (например, открыли файл локально без хостинга) —
   тихо откатывается на значения по умолчанию, чтобы страница не сломалась. */
async function getData() {
  try {
    const res = await fetch(DATA_URL + '?t=' + Date.now(), { cache: 'no-store' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const parsed = await res.json();
    return deepMerge(DEFAULT_DATA, parsed);
  } catch (e) {
    console.error('Не удалось загрузить данные с сервера, использую значения по умолчанию:', e);
    return getDefaultData();
  }
}

/* Сохраняет данные на сервере через api/save.php.
   Требует пароль редактора (тот же, что задан в api/config.php).
   Возвращает { ok:true } либо { ok:false, error } — текст ошибки можно
   показать пользователю (например «неверный пароль»). */
async function saveData(data, password) {
  try {
    const res = await fetch(SAVE_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Admin-Password': password || ''
      },
      body: JSON.stringify(data)
    });
    let result = {};
    try { result = await res.json(); } catch (e) { /* сервер не вернул JSON */ }
    if (!res.ok || !result.ok) {
      return { ok: false, error: result.error || ('Сервер ответил ошибкой (' + res.status + ')') };
    }
    return { ok: true };
  } catch (e) {
    console.error('Не удалось сохранить данные на сервере:', e);
    return { ok: false, error: 'Не удалось связаться с сервером. Проверь интернет-соединение.' };
  }
}

/* Отправляет ответ посетителя ("написать пару слов в ответ") на сервер —
   без пароля, это публичная форма, как обычная гостевая книга. */
async function sendReply(text) {
  try {
    const res = await fetch(REPLIES_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });
    const result = await res.json().catch(() => ({ ok: false }));
    return !!(res.ok && result.ok);
  } catch (e) {
    console.error('Не удалось отправить ответ:', e);
    return false;
  }
}

/* Загружает список ответов посетителей (для панели редактора). Требует пароль. */
async function fetchReplies(password) {
  const res = await fetch(REPLIES_URL, {
    headers: { 'X-Admin-Password': password || '' }
  });
  const result = await res.json().catch(() => ({ ok: false }));
  if (!res.ok || !result.ok) {
    throw new Error(result.error || ('HTTP ' + res.status));
  }
  return result.replies || [];
}
