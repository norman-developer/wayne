(async function(){
  let data = await getData();
  let dirty = false;

  const $ = id => document.getElementById(id);

  /* Пароль редактора — вводится один раз и держится в этой вкладке (sessionStorage),
     чтобы не набирать его при каждом сохранении. Сам пароль задаётся на сервере,
     в файле api/config.php. */
  const PASSWORD_KEY = 'giftSiteAdminPassword';
  $('f-adminPassword').value = sessionStorage.getItem(PASSWORD_KEY) || '';
  $('f-adminPassword').addEventListener('input', () => {
    sessionStorage.setItem(PASSWORD_KEY, $('f-adminPassword').value);
  });
  function currentPassword(){ return $('f-adminPassword').value; }

  function markDirty(){
    dirty = true;
    const pill = $('savePill');
    pill.textContent = '● есть несохранённые изменения';
    pill.classList.add('dirty');
  }
  function markClean(){
    dirty = false;
    const pill = $('savePill');
    pill.textContent = '✓ сохранено';
    pill.classList.remove('dirty');
  }
  function markError(message){
    dirty = true;
    const pill = $('savePill');
    pill.textContent = '✕ не сохранено';
    pill.classList.add('dirty');
    alert('Не удалось сохранить: ' + message);
  }

  /* ---------- load simple fields ---------- */
  function loadForm(){
    $('f-recipient').value = data.recipient;
    $('f-intro1').value = data.intro.line1;
    $('f-intro2').value = data.intro.line2;
    $('f-envhint').value = data.envelope.hint;

    $('f-kicker').value = data.letter.kicker;
    $('f-title').value = data.letter.title;
    $('f-body').value = data.letter.body;
    $('f-from').value = data.letter.from;
    $('f-thanksLabel').value = data.thanksButtonLabel;
    setPillGroup('handwritingPills', data.letter.handwriting);
    setPillGroup('langPills', data.letter.language);

    $('f-menuTitle').value = data.menu.title;
    $('f-heartsTarget').value = data.movie.heartsTarget;
    $('f-movieSubtitle').value = data.movie.subtitle;
    if (data.movie.photo){
      $('moviePhotoThumb').src = data.movie.photo;
      $('moviePhotoThumb').classList.remove('hidden');
    }

    $('f-allowShare').checked = !!data.settings.allowShare;
    $('f-allowReply').checked = !!data.settings.allowReply;
    $('f-showBranding').checked = !!data.settings.showBranding;
    $('f-shareUrl').value = data.settings.shareUrl || '';
    data.theme = data.theme || {preset:'original',menuStyle:'cards'};
    $('f-theme').value = data.theme.preset || 'original';
    $('f-menuStyle').value = data.theme.menuStyle || 'cards';
    data.security = data.security || {enabled:false,question:'Введите ключ',hint:'',password:''};
    $('f-securityEnabled').checked = !!data.security.enabled;
    $('f-securityQuestion').value = data.security.question || '';
    $('f-securityHint').value = data.security.hint || '';
    $('f-securityPassword').value = data.security.password || '';
    data.music = data.music || {enabled:false,src:'',fileName:'',volume:.35,autoplay:false};
    $('f-musicEnabled').checked = !!data.music.enabled;
    $('f-musicVolume').value = Number(data.music.volume ?? .35);
    $('volumeValue').textContent = Math.round(Number(data.music.volume ?? .35)*100)+'%';
    $('f-musicAutoplay').checked = !!data.music.autoplay;
    $('musicName').textContent = data.music.fileName ? 'Загружено: '+data.music.fileName : 'Файл ещё не выбран';

    $('f-farewellEnabled').checked = !!(data.farewell && data.farewell.enabled);
    $('f-farewellCaption').value = (data.farewell && data.farewell.caption) || '';
    if (data.farewell && data.farewell.image){
      $('farewellImageThumb').src = data.farewell.image;
      $('farewellImageThumb').classList.remove('hidden');
    }

    renderPhotos();
    renderMenuItems();
  }

  function setPillGroup(groupId, val){
    document.querySelectorAll(`#${groupId} .pill`).forEach(p => {
      p.classList.toggle('active', p.dataset.val === val);
    });
  }
  document.querySelectorAll('.pill-group').forEach(group => {
    group.addEventListener('click', e => {
      const btn = e.target.closest('.pill');
      if (!btn) return;
      setPillGroup(group.id, btn.dataset.val);
      markDirty();
    });
  });

  /* ---------- photos ---------- */
  function renderPhotos(){
    const wrap = $('photoList');
    wrap.innerHTML = '';
    data.photos.forEach((p, i) => {
      const div = document.createElement('div');
      div.className = 'photo-item';
      div.innerHTML = `
        <button type="button" class="remove-x" data-i="${i}">✕</button>
        ${p.src ? `<img class="thumb" src="${p.src}">` : ''}
        <label style="margin-top:0">Файл</label>
        <input type="file" accept="image/*" data-role="photo-file" data-i="${i}">
        <label>Подпись</label>
        <input type="text" data-role="photo-caption" data-i="${i}" value="${(p.caption||'').replace(/"/g,'&quot;')}" placeholder="например: Наше воспоминание">
      `;
      wrap.appendChild(div);
    });

    wrap.querySelectorAll('[data-role="photo-file"]').forEach(inp => {
      inp.addEventListener('change', e => {
        const i = +e.target.dataset.i;
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = () => {
          data.photos[i].src = reader.result;
          markDirty();
          renderPhotos();
        };
        reader.readAsDataURL(file);
      });
    });
    wrap.querySelectorAll('[data-role="photo-caption"]').forEach(inp => {
      inp.addEventListener('input', e => {
        data.photos[+e.target.dataset.i].caption = e.target.value;
        markDirty();
      });
    });
    wrap.querySelectorAll('.remove-x').forEach(btn => {
      btn.addEventListener('click', e => {
        data.photos.splice(+e.target.dataset.i, 1);
        markDirty();
        renderPhotos();
      });
    });
  }
  $('addPhotoBtn').addEventListener('click', () => {
    if (data.photos.length >= 5) return alert('Можно добавить не больше пяти фотографий.');
    data.photos.push({ src:'', caption:'' });
    markDirty();
    renderPhotos();
  });

  /* ---------- menu items ---------- */
  const ICON_CHOICES = ['💗','🌹','☕','🍿','🎬','🎮','💬','🌙','🎨','🎧','🧩','🚶','🍽️','🌆','✨','🎁'];
  function renderMenuItems(){
    const wrap = $('menuItemList');
    wrap.innerHTML = '';
    data.menu.items.forEach((item, i) => {
      const div = document.createElement('div');
      div.className = 'menu-item-edit';
      div.innerHTML = `
        <button type="button" class="remove-x" data-i="${i}">✕</button>
        <div class="two-col">
          <div>
            <label style="margin-top:0">Иконка</label>
            <select data-role="mi-icon" data-i="${i}">
              ${ICON_CHOICES.map(ic => `<option value="${ic}" ${ic===item.icon?'selected':''}>${ic}</option>`).join('')}
            </select>
          </div>
          <div>
            <label style="margin-top:0">Режим</label>
            <select data-role="mi-mode" data-i="${i}">
              <option value="movie" ${item.mode==='movie'?'selected':''}>с мини-игрой (сердечки)</option>
              <option value="simple" ${item.mode==='simple'?'selected':''}>просто фраза</option>
            </select>
          </div>
        </div>
        <label>Текст пункта</label>
        <input type="text" data-role="mi-label" data-i="${i}" value="${(item.label||'').replace(/"/g,'&quot;')}">
        <label>Финальная фраза (после выбора)</label>
        <textarea data-role="mi-final" data-i="${i}" rows="2">${item.finalPhrase||''}</textarea>
      `;
      wrap.appendChild(div);
    });

    wrap.querySelectorAll('[data-role="mi-icon"]').forEach(el => el.addEventListener('change', e => {
      data.menu.items[+e.target.dataset.i].icon = e.target.value; markDirty();
    }));
    wrap.querySelectorAll('[data-role="mi-mode"]').forEach(el => el.addEventListener('change', e => {
      data.menu.items[+e.target.dataset.i].mode = e.target.value; markDirty();
    }));
    wrap.querySelectorAll('[data-role="mi-label"]').forEach(el => el.addEventListener('input', e => {
      data.menu.items[+e.target.dataset.i].label = e.target.value; markDirty();
    }));
    wrap.querySelectorAll('[data-role="mi-final"]').forEach(el => el.addEventListener('input', e => {
      data.menu.items[+e.target.dataset.i].finalPhrase = e.target.value; markDirty();
    }));
    wrap.querySelectorAll('.remove-x').forEach(btn => btn.addEventListener('click', e => {
      if (data.menu.items.length <= 1) return alert('Должен остаться хотя бы один пункт.');
      data.menu.items.splice(+e.target.dataset.i, 1); markDirty(); renderMenuItems();
    }));
  }
  $('addMenuItemBtn').addEventListener('click', () => {
    if (data.menu.items.length >= 6) return alert('Можно добавить не больше шести пунктов.');
    data.menu.items.push({ icon:'💗', label:'Новый пункт', finalPhrase:'Договорились)', mode:'simple' });
    markDirty();
    renderMenuItems();
  });

  /* ---------- movie photo ---------- */
  $('moviePhotoInput').addEventListener('change', e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      data.movie.photo = reader.result;
      $('moviePhotoThumb').src = reader.result;
      $('moviePhotoThumb').classList.remove('hidden');
      markDirty();
    };
    reader.readAsDataURL(file);
  });

  /* ---------- farewell image ---------- */
  $('farewellImageInput').addEventListener('change', e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      data.farewell.image = reader.result;
      $('farewellImageThumb').src = reader.result;
      $('farewellImageThumb').classList.remove('hidden');
      markDirty();
    };
    reader.readAsDataURL(file);
  });

  /* ---------- music ---------- */
  $('musicInput').addEventListener('change', e => {
    const file = e.target.files[0]; if (!file) return;
    if (file.size > 8 * 1024 * 1024) return alert('Аудиофайл слишком большой. Для хранения в текущем JSON выбери файл до 8 МБ.');
    const reader = new FileReader();
    reader.onload = () => { data.music.src = reader.result; data.music.fileName = file.name; $('musicName').textContent = 'Загружено: '+file.name; markDirty(); };
    reader.readAsDataURL(file);
  });
  $('f-musicVolume').addEventListener('input', () => { $('volumeValue').textContent = Math.round(Number($('f-musicVolume').value)*100)+'%'; markDirty(); });

  /* ---------- generic input listeners ---------- */
  [
    'f-recipient','f-intro1','f-intro2','f-envhint','f-kicker','f-title','f-body','f-from',
    'f-thanksLabel','f-menuTitle','f-heartsTarget','f-movieSubtitle','f-shareUrl','f-farewellCaption','f-theme','f-menuStyle','f-securityQuestion','f-securityHint','f-securityPassword'
  ].forEach(id => $(id).addEventListener('input', markDirty));
  ['f-allowShare','f-allowReply','f-showBranding','f-farewellEnabled','f-securityEnabled','f-musicEnabled','f-musicAutoplay'].forEach(id => $(id).addEventListener('change', markDirty));

  /* ---------- collect + save ---------- */
  function collectForm(){
    data.recipient = $('f-recipient').value.trim() || 'Дорогой человек';
    data.intro.line1 = $('f-intro1').value;
    data.intro.line2 = $('f-intro2').value;
    data.envelope.hint = $('f-envhint').value;

    data.letter.kicker = $('f-kicker').value;
    data.letter.title = $('f-title').value;
    data.letter.body = $('f-body').value;
    data.letter.from = $('f-from').value;
    data.thanksButtonLabel = $('f-thanksLabel').value || 'Спасибо ♡';
    data.letter.handwriting = document.querySelector('#handwritingPills .pill.active')?.dataset.val || 'handwritten';
    data.letter.language = document.querySelector('#langPills .pill.active')?.dataset.val || 'ru';

    data.menu.title = $('f-menuTitle').value;
    data.movie.heartsTarget = parseInt($('f-heartsTarget').value,10) || 20;
    data.movie.subtitle = $('f-movieSubtitle').value;

    data.settings.allowShare = $('f-allowShare').checked;
    data.settings.allowReply = $('f-allowReply').checked;
    data.settings.showBranding = $('f-showBranding').checked;
    data.settings.shareUrl = $('f-shareUrl').value.trim();
    data.theme.preset = $('f-theme').value;
    data.theme.menuStyle = $('f-menuStyle').value;
    data.security.enabled = $('f-securityEnabled').checked;
    data.security.question = $('f-securityQuestion').value;
    data.security.hint = $('f-securityHint').value;
    data.security.password = $('f-securityPassword').value;
    data.music.enabled = $('f-musicEnabled').checked;
    data.music.volume = Number($('f-musicVolume').value);
    data.music.autoplay = $('f-musicAutoplay').checked;

    data.farewell.enabled = $('f-farewellEnabled').checked;
    data.farewell.caption = $('f-farewellCaption').value;

    return data;
  }

  async function doSave(){
    collectForm();
    const saveBtn = $('saveMainBtn');
    saveBtn.disabled = true;
    const result = await saveData(data, currentPassword());
    saveBtn.disabled = false;
    if (result.ok){
      markClean();
      refreshPreview();
    } else {
      markError(result.error);
    }
  }

  $('saveMainBtn').addEventListener('click', doSave);

  $('resetBtn').addEventListener('click', async () => {
    if (!confirm('Сбросить все изменения к примеру по умолчанию?')) return;
    data = getDefaultData();
    loadForm();
    await doSave();
  });

  /* ---------- ответы посетителей ---------- */
  $('loadRepliesBtn').addEventListener('click', async () => {
    const list = $('repliesList');
    list.innerHTML = '<p class="replies-empty">Загрузка…</p>';
    try {
      const replies = await fetchReplies(currentPassword());
      if (!replies.length){
        list.innerHTML = '<p class="replies-empty">Пока никто не ответил.</p>';
        return;
      }
      list.innerHTML = replies.map(r => {
        const when = new Date(r.when).toLocaleString('ru-RU');
        return `<div class="reply-item"><p>${escapeHtmlAdmin(r.text)}</p><time>${when}</time></div>`;
      }).join('');
    } catch (e) {
      list.innerHTML = '<p class="replies-error">Не удалось загрузить: ' + escapeHtmlAdmin(e.message) + '</p>';
    }
  });
  function escapeHtmlAdmin(str){
    const d = document.createElement('div');
    d.textContent = str;
    return d.innerHTML;
  }

  /* ---------- preview ---------- */
  function refreshPreview(){
    const frame = $('previewFrame');
    frame.src = 'index.html?t=' + Date.now();
  }
  $('refreshPreviewBtn').addEventListener('click', () => { doSave(); });

  // Сохранение теперь идёт на сервер (не мгновенно, как раньше localStorage),
  // поэтому при уходе со страницы просто предупреждаем о несохранённых правках,
  // а не пытаемся неявно сохранить их в фоне.
  window.addEventListener('beforeunload', (e) => {
    if (!dirty) return;
    e.preventDefault();
    e.returnValue = '';
  });

  loadForm();
})();
