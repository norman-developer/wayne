<?php
/* Общие маленькие помощники для api/save.php и api/replies.php.
   Никакого фреймворка и "тяжёлой" авторизации — только то, что нужно. */

header('Content-Type: application/json; charset=utf-8');

function send_json($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/* Пароль можно передать заголовком X-Admin-Password (так делает наш JS)
   или, на всякий случай, параметром ?password=... — например для ручной
   проверки в браузере. Сравнение через hash_equals защищает от простых
   атак по времени ответа. */
function check_password() {
    $sent = $_SERVER['HTTP_X_ADMIN_PASSWORD'] ?? ($_GET['password'] ?? '');
    if (!is_string($sent) || $sent === '' || !hash_equals(ADMIN_PASSWORD, $sent)) {
        send_json(['ok' => false, 'error' => 'Неверный пароль редактора'], 401);
    }
}

function read_json_file($path, $default) {
    if (!file_exists($path)) return $default;
    $raw = @file_get_contents($path);
    if ($raw === false) return $default;
    $parsed = json_decode($raw, true);
    return $parsed === null && $raw !== 'null' ? $default : $parsed;
}

/* Пишем во временный файл и переименовываем — так посетитель никогда не
   увидит наполовину записанный файл, даже если два сохранения совпадут
   по времени. */
function write_json_file_atomic($path, $data) {
    $tmp = $path . '.tmp-' . getmypid();
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if ($json === false) return false;
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    if (!@rename($tmp, $path)) {
        @unlink($tmp);
        return false;
    }
    return true;
}
