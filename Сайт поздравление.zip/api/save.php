<?php
/* Сохраняет содержимое открытки (data/data.json). Вызывается из admin.js
   при нажатии «Сохранить». Требует пароль редактора — без него ничего
   не запишется. */

require __DIR__ . '/config.php';
require __DIR__ . '/_common.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json(['ok' => false, 'error' => 'Метод не поддерживается'], 405);
}

check_password();

$raw = file_get_contents('php://input');
if ($raw === false || $raw === '') {
    send_json(['ok' => false, 'error' => 'Пустой запрос'], 400);
}
if (strlen($raw) > MAX_BODY_SIZE) {
    send_json(['ok' => false, 'error' => 'Слишком много данных — возможно, фотографии слишком большие'], 413);
}

$data = json_decode($raw, true);
if (!is_array($data)) {
    send_json(['ok' => false, 'error' => 'Некорректный формат данных'], 400);
}

if (!write_json_file_atomic(DATA_FILE, $data)) {
    send_json([
        'ok' => false,
        'error' => 'Не удалось записать файл data/data.json. Проверь права на папку data/ (обычно нужно выставить 755 или 775, а на некоторых хостингах — 777).'
    ], 500);
}

send_json(['ok' => true]);
