<?php
/* Ответы получателя ("написать пару слов в ответ").
   POST — отправить ответ, доступно всем (как обычная форма на сайте).
   GET  — прочитать список ответов, только с паролем редактора
          (иначе личные сообщения мог бы прочитать кто угодно по прямой ссылке). */

require __DIR__ . '/config.php';
require __DIR__ . '/_common.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $raw = file_get_contents('php://input');
    if ($raw === false || strlen($raw) > 20000) {
        send_json(['ok' => false, 'error' => 'Слишком длинное сообщение'], 413);
    }

    $body = json_decode($raw, true);
    $text = isset($body['text']) ? trim((string) $body['text']) : '';
    if ($text === '') {
        send_json(['ok' => false, 'error' => 'Пустой ответ'], 400);
    }
    if (mb_strlen($text) > 300) {
        $text = mb_substr($text, 0, 300);
    }

    $replies = read_json_file(REPLIES_FILE, []);
    if (!is_array($replies)) $replies = [];
    $replies[] = [
        'text' => $text,
        'when' => date('c'),
    ];
    // Не даём файлу расти бесконечно — оставляем последние 200 ответов.
    if (count($replies) > 200) {
        $replies = array_slice($replies, -200);
    }

    if (!write_json_file_atomic(REPLIES_FILE, $replies)) {
        send_json(['ok' => false, 'error' => 'Не удалось сохранить ответ на сервере'], 500);
    }

    send_json(['ok' => true]);
}

if ($method === 'GET') {
    check_password();
    $replies = read_json_file(REPLIES_FILE, []);
    if (!is_array($replies)) $replies = [];
    send_json(['ok' => true, 'replies' => array_reverse($replies)]);
}

send_json(['ok' => false, 'error' => 'Метод не поддерживается'], 405);
